package funaverage57.customweapons.items;

import net.minecraft.item.IItemTier;
import net.minecraft.item.PickaxeItem;

public class ItemCustomPickaxe extends PickaxeItem{
	public ItemCustomPickaxe(IItemTier tier, int attackDamage, float attackSpeedIn, Properties builder) {
		super(tier, attackDamage, attackSpeedIn, builder);
	}
}
