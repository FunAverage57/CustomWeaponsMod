package funaverage57.customweapons.items;

import net.minecraft.item.AxeItem;
import net.minecraft.item.IItemTier;

public class ItemCustomAxe extends AxeItem{
	public ItemCustomAxe(IItemTier tier, float attackDamage, float attackSpeedIn, Properties builder) {
		super(tier, attackDamage, attackSpeedIn, builder);
	}
}
