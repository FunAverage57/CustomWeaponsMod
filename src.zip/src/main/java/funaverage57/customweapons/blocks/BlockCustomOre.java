package funaverage57.customweapons.blocks;

import java.util.Random;

import funaverage57.customweapons.lists.BlockList;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.OreBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;

public class BlockCustomOre extends OreBlock{
	public BlockCustomOre(Block.Properties properties) {
	      super(properties);
	   }

	   protected int func_220281_a(Random p_220281_1_) {
	      if (this == BlockList.kyber_blue_ore) {
	         return MathHelper.nextInt(p_220281_1_, 3, 7);
	      } else if (this == BlockList.kyber_green_ore) {
	         return MathHelper.nextInt(p_220281_1_, 3, 7);
	      } else if (this == BlockList.kyber_purple_ore) {
		     return MathHelper.nextInt(p_220281_1_, 3, 7);
		  } else if (this == BlockList.kyber_red_ore) {
		     return MathHelper.nextInt(p_220281_1_, 3, 7);
		  }  else if (this == BlockList.ruby_ore) {
		     return MathHelper.nextInt(p_220281_1_, 3, 7);
		  } else if (this == BlockList.sapphire_ore) {
			 return MathHelper.nextInt(p_220281_1_, 3, 7);
		}  else {
	         return this == BlockList.crystallite_ore ? MathHelper.nextInt(p_220281_1_, 2, 5) : 0;
	      }
	   }

	   /**
	    * Perform side-effects from block dropping, such as creating silverfish
	    */
	   public void spawnAdditionalDrops(BlockState state, World worldIn, BlockPos pos, ItemStack stack) {
	      super.spawnAdditionalDrops(state, worldIn, pos, stack);
	   }

	   @Override
	   public int getExpDrop(BlockState state, net.minecraft.world.IWorldReader reader, BlockPos pos, int fortune, int silktouch) {
	      return silktouch == 0 ? this.func_220281_a(RANDOM) : 0;
	   }
}
